### Instructions

- Right click on Solution Explorer
- Select Restore NuGet packages.
- For SQL-Server samples, run script.sql found under each SQL-Server projects under the folder DatabaseScripts. Make sure to first open the script and checking the path to where the database will be installed. If the path is different from yours, change it.
- Build the solution.
- Run desired examples.